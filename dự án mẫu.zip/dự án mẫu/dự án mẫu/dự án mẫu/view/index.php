<?php
session_start();
include "../model/pdo.php";
include "../model/danhmuc.php";
include "../model/sanpham.php";
include "../model/taikhoan.php";
include "header.php";
include "../view/global.php";
if(!isset($_SESSION['mycart'])) $_SESSION['mycart']=[];
$spnew = loadall_sanpham_home();
$dsdm = loadall_danhmuc();
$dstop10 = loadall_sanpham_top10();

if ((isset($_GET['act'])) && ($_GET['act'] != "")) {
    $act = $_GET['act'];
    switch ($act) {
            // san pham
        case 'sanpham':
            if (isset($_POST['kwy']) && ($_POST['kwy']) > 0) {
                $kwy = $_POST['kwy'];
            } else {
                $kwy = "";
            }
            if (isset($_GET['id_dm']) && ($_GET['id_dm']) > 0) {
                $iddm = $_GET['id_dm'];
            } else {
                $iddm = 0;
            }
            $dssp = loadall_sanpham($kwy, $iddm);
            $tendm = load_ten_danhmuc($iddm);
            include "../view/sanpham.php";
            break;
            // san pham chi tiet
        case 'sanphamct':
            if (isset($_GET['idsp']) && ($_GET['idsp']) > 0) {
                $id = $_GET['idsp'];
                $onesp = loadone_sanpham($id);
                extract($onesp);
                $sp_cung_loai = load_sp_cungloai($id, $id_dm);
                include "../view/sanphamct.php";
            } else {
                include "../view/sanphamct.php";
            }
            break;
            // tai khoan
        case 'dangky':
            if (isset($_POST['dangky']) && ($_POST['dangky'])) {
                $email = $_POST['email'];
                $user = $_POST['user'];
                $pass = $_POST['pass'];
                inser_taikhoan($user, $pass, $email);
                $thongbao = "đã đăng ký thông công.Vui lòng đăng nhập để thực hiện chức năng bình hoặc mua hàng!";
            }
            include "../view/taikhoan/dangky.php";
            break;
        case 'dangnhap':
            if (isset($_POST['dangnhap']) && ($_POST['dangnhap'])) {
                $user = $_POST['user'];
                $pass = $_POST['pass'];
                $check_user = check_user($user, $pass);
                if (is_array($check_user)) {
                    $_SESSION['user'] = $check_user;
                    // $thongbao = "Tài khoản đăng nhập thành công!";
                    header('location: index.php');
                } else {
                    $thongbao = "Tài khoản không tồn tại.Vui lòng kiểm tra hoặc đăng ký!";
                }
            }
            include "../view/taikhoan/dangky.php";
            break;
        case 'edit_taikhoan':
            if (isset($_POST['capnhat']) && ($_POST['capnhat'])) {
                $email = $_POST['email'];
                $user = $_POST['user'];
                $pass = $_POST['pass'];
                $address = $_POST['address'];
                $tel = $_POST['tel'];
                $id = $_POST['id'];
                update_taikhoan($email, $user, $pass, $address, $tel, $id);
                $_SESSION['user'] = check_user($user, $pass);
                header('location: index.php?act=edit_taikhoan');
            }
            include "../view/taikhoan/edit_taikhoan.php";
            break;
        case 'quen_mk': 
            if (isset($_POST['guiemail']) && ($_POST['guiemail'])) {
                $email = $_POST['email'];
                $check_email = check_email($email);
                if (is_array($check_email)) {
                    $thongbao = "Mật khẩu của bạn là:" . $check_email['pass'];
                } else {
                    $thongbao = "email này không tồn tại";
                }
            }
            include "../view/taikhoan/quen_mk.php";
            break;
        case 'thoat':
            session_unset();
            header('location: index.php');
            break;
        case 'addtocart':
            if (isset($_POST['addtocart']) && ($_POST['addtocart'])) {
                $id=$_POST['id'];
                $name=$_POST['name'];
                $img=$_POST['img'];
                $price=$_POST['price'];
                $songluong=1;
                $thanhtien=$songluong * $price;
                $spadd=[$id,$name,$img,$price,$songluong,$thanhtien];
                // day mot mang con len mot mang cha  (lên dòng 9)
                array_push($_SESSION['mycart'],$spadd);
            }
            break;
        case 'gioithieu':
            include "../view/gioithieu.php";
            break;
        case 'lienhe':
            include "../view/lienhe.php";
            break;
        default:
            include "home.php";
            break;
    }
} else {
    include "home.php";
}
include "footer.php";
