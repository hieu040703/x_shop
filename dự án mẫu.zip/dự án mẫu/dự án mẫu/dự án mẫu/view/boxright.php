<div class="row mb">
    <div class="boxtile">TÀI KHOẢN</div>
    <div class="boxconter formtaikhoan">
        <?php
        if (isset($_SESSION['user'])) {
            extract($_SESSION['user']);
        ?>
            <div class="row mb10">
               xin chào<br><?=$user?>
            </div>
            <div class="row mb10">
                <li>
                    <a href="index.php?act=quen_mk">Quên mật khẩu</a>
                </li>
                <li>
                    <a href="index.php?act=edit_taikhoan">Cập nhật tài khoản</a>
                </li>
                <?php if($role==1){?>
                <li>
                    <a href="../admin/index.php">Đăng Nhập Admin</a>
                </li>
                <?php }?>
                <li>
                    <a href="index.php?act=thoat">Thoát</a>
                </li>
            </div>
        <?php
        } else {
        ?>
            <form action="index.php?act=dangnhap" method="post">
                <div class="row mb10">
                    Tên đăng nhập<br>
                    <input type="text" name="user">
                </div>
                <div class="row mb10">
                    Mật khẩu <br>
                    <input type="password" name="pass">
                </div>
                <div class="row mb10">
                    <input type="checkbox" name="">Ghi nhớ tài khoản?
                </div>
                <div class="row mb10">
                    <input type="submit" name="dangnhap" value="Đăng nhập">
                </div>
            </form>
            <li>
                <a href="index.php?act=quen_mk">Quên mật khẩu</a>
            </li>
            <li>
                <a href="index.php?act=dangky">Đăng ký thành viên</a>
            </li>
        <?php } ?>
    </div>
</div>


<!-- hien thi danh muc -->
<div class="row mb">
    <div class="boxtile">DANH MỤC</div>
    <div class="boxconter2 menudoc">
        <ul>
            <?php
            foreach ($dsdm as $dm) {
                extract($dm);
                $linkdm = "index.php?act=sanpham&id_dm=" . $id;
                echo '<li>
                      <a href="' . $linkdm . '">' . $name . '</a>
                      </li>';
            }
            ?>
        </ul>
    </div>
    <div class="boxfooter searbox">
        <form action="index.php?act=sanpham" method="post">
            <input type="text" name="kwy">
            <input type="submit" name="name" value="tìm kiếm">
        </form>
    </div>
</div>
<!--hien thi top 10 yeu thich -->
<div class="row">
    <div class="boxtile">TOP 10 YÊU THÍCH</div>
    <div class="row boxconter">
        <?php
        foreach ($dstop10 as $sp) {
            extract($sp);
            $linksp = "index.php?act=sanphamct&idsp=" . $id;
            $img = $img_path . $img;
            echo ' <div class="row mb10 top10">
                    <a href="' . $linksp . '"><img src="' . $img . '"></a>
                    <a href="' . $linksp . '">' . $name . '</a>
                  </div>';
        }
        ?>
    </div>
</div>