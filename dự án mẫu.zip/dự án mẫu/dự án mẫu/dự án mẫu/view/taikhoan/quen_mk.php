<div class="row mb">
    <div class="boxtrai mr">
        <div class="row mb">
            <div class="boxtile">Quên mật khẩu</div>
            <div class="row boxconter formtaikhoan">
                <form action="index.php?act=quen_mk" method="post">
                    <div class="row mb10">
                        Email
                        <input type="email" name="email" style=" width: 100%;
                        border: 1px #ccc solid;
                        padding: 5px 10px;
                        border-radius: 5px;">
                    </div>
                    <input type="submit" name="guiemail" value="Gửi">
                    <input type="reset" value="nhập lại">
                </form>
                 <h2 class="thongbao">
                 <?php
                    if(isset($thongbao)&&($thongbao!="")){
                        echo $thongbao;
                    }
                    ?>
                 </h2>
            </div>
        </div>

    </div>
    <div class="boxphai">
        <?php
        include "../view/boxright.php";
        ?>
    </div>
</div>