<div class="row mb">
    <div class="boxtrai mr">
        <div class="row mb">
            <div class="boxtile">Đăng ký thành viên</div>
            <div class="row boxconter formtaikhoan">
                <form action="index.php?act=dangky" method="post">
                    <div class="row mb10">
                        Email
                        <input type="email" name="email" style=" width: 100%;
                        border: 1px #ccc solid;
                        padding: 5px 10px;
                        border-radius: 5px;">
                    </div>
                    <div class="row mb10">
                        Tên đăng nhập
                        <input type="text" name="user">
                    </div>
                    <div class="row mb10">
                        Mật khẩu
                        <input type="password" name="pass">
                    </div>
                    <input type="submit" name="dangky" value="đăng ký">
                    <input type="reset" value="nhập lại">
                </form>
                 <h2 class="thongbao">
                 <?php
                    if(isset($thongbao)&&($thongbao!="")){
                        echo $thongbao;
                    }
                    ?>
                 </h2>
            </div>
        </div>
    </div>
    <div class="boxphai">
        <?php
        include "../view/boxright.php";
        ?>
    </div>
</div>