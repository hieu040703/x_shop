<div class="row mb">
    <div class="boxtrai mr">
       <div class="row mb">
         <?php
         extract($onesp);
         ?>
         <div class="boxtile"><?=$name?></div>
         <div class="row boxconter">  
            <?php
            $hinh=$img_path.$img;
            echo '<div class="row mb spct"><img src="'.$hinh.'"> </div>';
            echo $describe;
            ?>
         </div>
      </div>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
       <!--binh luan-->
      <script>
         $(document).ready(function(){
            $("#binhluan").load("../view/binhluan/binhluan_form.php",{idpro: <?=$id?>});
         })
      </script>
      <div class="row " id="binhluan">
         
      </div>  
      <!--san pham cung loai -->
      <div class="row mb">
         <div class="boxtile">Sản Phẩm Cùng Loại</div>
         <div class="row boxconter">  
            <?php
            foreach ($sp_cung_loai as $sp_cung_loai) {
              extract($sp_cung_loai);
             
              $linksp="index.php?act=sanphamct&idsp=".$id;
              echo '<li><a href="'.$linksp.'">'.$name.'</a></li>';
            }
            ?>
         </div>
      </div>
    </div>
    <div class="boxphai">
       <?php
       include "../view/boxright.php";
       ?>
    </div>
</div>