<div class="row mb">
    <div class="boxtrai mr">
        <div class="row">
            <div class="banner">
                <!-- Slideshow container -->
                <div class="slideshow-container">
                    <!-- Full-width images with number and caption text -->
                    <div class="mySlides fade">
                        <div class="text">Caption Text</div>
                        <img src="../view/images/banner1.jpg" style="width:100%">
                    </div>

                    <div class="mySlides fade">
                        <div class="text">Caption Two</div>
                        <img src="../view/images/banner2.jpg" style="width:100%">
                    </div>

                    <div class="mySlides fade">
                        <div class="text">Caption Three</div>
                        <img src="../view/images/banner3.jpg" style="width:100%">
                    </div>
                    <!-- Next and previous buttons -->
                </div>
                <br>
                <!-- The dots/circles -->
                <div style="text-align:center">
                    <span class="dot" onclick="currentSlide(1)"></span>
                    <span class="dot" onclick="currentSlide(2)"></span>
                    <span class="dot" onclick="currentSlide(3)"></span>
                </div>
            </div>
        </div>
            <!--load du lieu tren danh muc san pham-->
        <div class="row">
            <?php
            $i = 0;
            foreach ($spnew as $sp) {
                extract($sp);
                $linksp = "index.php?act=sanphamct&idsp=" . $id;
                $hinh = $img_path . $img;
                if (($i == 2) || ($i == 5) || ($i == 8)) {
                    $mr = "";
                } else {
                    $mr = "mr";
                }
                $i += 0;
                echo '<div class="boxsp ' . $mr . '">
                <div class="row img"><a href="' . $linksp . '"></a><img src="' . $hinh . '" alt=""></div>
                 <p>' . $price . 'đ</p>
                <a class="a" href="' . $linksp . '">' . $name . '</a>
                <div class="row btnaddtocart">
                <form action="index.php?act=addtocart" method="post">
                    <input type="hidden" name="id" value="'.$id.'">
                    <input type="hidden" name="id" value="'.$name.'">
                    <input type="hidden" name="id" value="'.$img.'">
                    <input type="hidden" name="id" value="'.$price.'">
                    <input type="submit" name="addtocart" value="thêm vào giỏ hàng">
                </form>
                </div>
            </div>';
            }
            ?>
        </div>
    </div>
    <div class="boxphai">
        <?php
        include "../view/boxright.php";
        ?>
    </div>
</div>