<div class="row">
    <div class="boxtitle">giỏ hàng</div>
    <div class="row boxcontent cart">
        <table>
            <tr>
                <th>hình</th>
                <th>sản phẩm</th>
                <th>số lượng</th>
                <th>thành viên</th>
                <th>thao tác</th>
            </tr>
        </table>
    </div>
</div>
<div class="row mb bill">
        <input type="submit" value="đồng ý đặt hàng"> <a href="index.php?act=delacert"><input type="button" value="xóa giỏ hàng"></a>
</div>
</div>
<div class="boxphai">
    <?php
    include "../../view/boxright.php"
    ?>
</div>