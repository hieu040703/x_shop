<?php 
function inser_sanpham($tensp,$giasp,$hinh,$mota,$iddm){
    $sql="INSERT INTO `san_pham`( `name`, `price`, `img`, `describe`, `id_dm`) 
    VALUES ('{$tensp}','{$giasp}','{$hinh}','{$mota}','{$iddm}')";
    // echo $sql;
    // die ;
    pdo_execute($sql);
}
function delete_sanpham($id){
    $sql="DELETE FROM `san_pham` WHERE `id`=".$id;
    pdo_execute($sql);
}
// top 10 san pham yeu thich
function loadall_sanpham_top10(){
    $sql = "SELECT * FROM san_pham where 1 order by `view` desc limit 0,10";
    $listsanpham=pdo_query($sql);
    return  $listsanpham;
}
// top 10 trang chu
function loadall_sanpham_home(){
    $sql = "SELECT * FROM san_pham where 1 order by `id` desc limit 0,9";
    $listsanpham=pdo_query($sql);
    return  $listsanpham;
}


function loadall_sanpham($kwy="",$iddm=0){
    $sql = "SELECT * FROM san_pham where 1";
    if($kwy!=""){
        $sql.=" and name like '%" .$kwy. "%'";
    }
    if($iddm>0){
        $sql.=" and id_dm =".$iddm."";
    }
    $sql.=" order by id desc";
    $listsanpham=pdo_query($sql);
    return  $listsanpham;
}
function load_ten_danhmuc($iddm){
  if($iddm>0){
    $sql="SELECT * FROM `danh_muc` where `id`=".$iddm;
    $dm=pdo_query_one($sql);
    extract($dm);
    return $name;
  }else{
    return "";
  }
}
function loadone_sanpham($id){
    $sql="SELECT * FROM `san_pham` where `id`=".$id;
    $sanpham=pdo_query_one($sql);
    return $sanpham;
}
function load_sp_cungloai($id,$id_dm){
    $sql="SELECT * FROM `san_pham` where `id_dm`=".$id_dm." AND `id`<>".$id;
    $listsanpham=pdo_query($sql);
    return  $listsanpham;
}
function update_sanpham($id, $tensp, $giasp, $mota, $hinh,$iddm){
   if($hinh!=""){
    $sql="UPDATE `san_pham` SET`name`='.$tensp.',`price`='.$giasp.',`img`='.$hinh.',`describe`='.$mota.',`id_dm`='.$iddm.' WHERE id=".$id;
   echo $sql;
   
  }else{   
    $sql="UPDATE `san_pham` SET`name`='.$tensp.',`price`='.$giasp.',`describe`='.$mota.',`id_dm`='.$iddm.' WHERE id=".$id;
}
    pdo_execute($sql);
}
function listdanhmuc()
{
    $sql = "SELECT * FROM `danh_muc` order by `id` desc";
    $listdanhmuc = pdo_query($sql);
    return $listdanhmuc;
}
?>