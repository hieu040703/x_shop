<?php
function loadall_taikhoan()
{
       $sql = "SELECT * FROM `tai_khoan` order by `id` desc";
       $listtaikhoan = pdo_query($sql);
       return $listtaikhoan;
}
function delete_taikhoan($id)
{
    $sql = "DELETE FROM `tai_khoan` WHERE `id`=" . $id;
    pdo_execute($sql);
}
function loadone_taikhoan($id)
{
    $sql = "SELECT * FROM `tai_khoan` where `id`=" . $id;
    $tk = pdo_query_one($sql);
    return $tk;
}

function inser_taikhoan($user,$pass,$email){
    $sql="INSERT INTO `tai_khoan`( `user`, `pass`, `email`) VALUES ('{$user}','{$pass}','{$email}')";
    pdo_execute($sql);
}
function check_user($user,$pass){
    $sql="SELECT * FROM `tai_khoan` where `user`='".$user."' AND `pass`='".$pass."'";
    $sanpham=pdo_query_one($sql);
    return $sanpham;
}
function check_email($email){
    $sql="SELECT * FROM `tai_khoan` where `email`='".$email."'";
    $sanpham=pdo_query_one($sql);
    return $sanpham;
}
function update_taikhoan1($email, $user, $pass, $address, $tel,$role,$id){
        $sql="UPDATE `tai_khoan` SET `user`='{$user}',`pass`='{$pass}',`email`='{$email}',`address`='{$address}',`tel`='{$tel}',`role`='{$role}' 
        WHERE id=".$id;
        pdo_execute($sql);
   }
   function update_taikhoan($email, $user, $pass, $address, $tel,$id){
    $sql="UPDATE `tai_khoan` SET `user`='{$user}',`pass`='{$pass}',`email`='{$email}',`address`='{$address}',`tel`='{$tel}'
    WHERE id=".$id;
    pdo_execute($sql);
}
?>