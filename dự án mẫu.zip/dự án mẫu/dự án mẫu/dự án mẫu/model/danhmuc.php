<?php
function inser_danhmuc($tenloai)
{
    $sql = "INSERT INTO `danh_muc`(`name`) VALUES ('{$tenloai}')";
    pdo_execute($sql);
}
function delete_danhmuc($id)
{
    $sql = "DELETE FROM `danh_muc` WHERE `id`=" . $id;
    pdo_execute($sql);
}
// load all danh muc
function loadall_danhmuc()
{
    $sql = "SELECT * FROM `danh_muc` order by `id` desc";
    $listdanhmuc = pdo_query($sql);
    return $listdanhmuc;
}
function loadone_danhmuc($id)
{
    $sql = "SELECT * FROM `danh_muc` where `id`=" . $id;
    $dm = pdo_query_one($sql);
    return $dm;
}

function update_danhmuc($id, $tenloai)
{
    $sql = "UPDATE `danh_muc` SET `name`= '" . $tenloai . "' WHERE id=" . $id;
    pdo_execute($sql);
}
?>