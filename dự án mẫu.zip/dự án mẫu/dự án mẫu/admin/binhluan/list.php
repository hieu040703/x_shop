<div class="row">
    <h1>Danh sách tài khoản</h1>
</div>
<div class="row frmcontent">
    <form action="#" method="post">
        <div class="row mb10 frmdsloai">
            <table>
                <tr>
                    <th></th>
                    <th>ID</th>
                    <th>Nội dung</th>
                    <th>Iduser</th>
                    <th>Idpro</th>
                    <th>Ngày bình luận</th>
                    <th></th>
                </tr>
                <?php
                // print_r($listdanhmuc);
                // die;
                foreach ($listbinhluan as $key=>$value ) {
                    extract($value);
                    $xoabl = "index.php?act=xoabl&id=" . $id;
                    echo '<tr>
                           <td><input type="checkbox"></td>
                           <td>' .$id. '</td>
                           <td>' .$noidung.'</td>
                           <td>' .$iduser. '</td>
                           <td>' .$idpro.'</td>
                           <td>' .$ngaybinhluan. '</td>
                           <td> <a href="' . $xoabl . '"><input type="button" value="Xóa"></a></td>
                       </tr>';
                }
                ?>
            </table>
        </div>
    </form>
    </form>
</div>