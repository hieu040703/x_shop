<div class="row">
    <div class="row frmtitle">
        <h1>thống kê sản phẩm theo loại</h1>
    </div>
    <div class="row frmcontent">
        <div class="row mb10 frmdsloai">
            <table>
                <tr>
                    <th>Mã danh mục</th>
                    <th>Tên danh mục</th>
                    <th>Số lượng</th>
                    <th>Gía cao nhất</th>
                    <th>giá thấp nhất</th>
                    <th>Gía trung bình</th>
                </tr>
                <?php
                foreach ($listthongke as $tk) {
                   extract($tk);
                   echo '<tr>
                        <td>'.$madm.'</td>
                        <td>'.$tendm.'</td>
                        <td>'.$countsp.'</td>
                        <td>'.$maxprice.'</td>
                        <td>'.$minprice.'</td>
                        <td>'.$avgprice.'</td>
                   </tr>';
                }
                ?>
            </table>
        </div>
        <div class="row mb10">
            <a href="index.php?act=bieudo"><input type="button" value="xem biểu đồ"></a>
        </div>
    </div>
</div>