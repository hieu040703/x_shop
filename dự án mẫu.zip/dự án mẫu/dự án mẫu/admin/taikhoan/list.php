<div class="row">
    <h1>Danh sách tài khoản</h1>
</div>
<div class="row frmcontent">
    <form action="#" method="post">
        <div class="row mb10 frmdsloai">
            <table>
                <tr>
                    <th></th>
                    <th>Mã tài khoản</th>
                    <th>Tên đăng nhập</th>
                    <th>Mật khẩu</th>
                    <th>Email</th>
                    <th>Địa chỉ</th>
                    <th>Điện thoại</th>
                    <th>Vai trò</th>
                    <th></th>
                </tr>
                <?php
                // print_r($listdanhmuc);
                // die;
                foreach ($listtaikhoan as $key=>$value ) {
                    extract($value);
                    $suatk = "index.php?act=suatk&id=" . $id;
                    $xoatk = "index.php?act=xoatk&id=" . $id;
                    echo '<tr>
                           <td><input type="checkbox"></td>
                           <td>' .$id. '</td>
                           <td>' .$user.'</td>
                           <td>' .$pass. '</td>
                           <td>' .$email.'</td>
                           <td>' .$address. '</td>
                           <td>' .$tel.'</td>
                           <td>' .$role.'</td>
                           <td><a href="' . $xoatk . '"> <input type="button" value="xóa"></a> <a href="' . $suatk . '"><input type="button" value="sửa"></a></td>
                       </tr>';
                }
                ?>
            </table>
        </div>
    </form>
    </form>
</div>