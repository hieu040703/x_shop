<?php
if (is_array($tk)) {
    extract($tk);
}
?>
<div class="row frmcontent">
    <form action="index.php?act=updatetk" method="post">
        <div class="row mb10">
            <input type="text" name="id" hidden  disabled>
        </div>
        <div class="row mb10">
            tên đăng nhập <br>
            <input type="text" name="user" value="<?php if (isset($user) && ($user != ""))
                echo $user; ?>">
        </div>
        <div class="row mb10">
           Mật khẩu <br>
            <input type="text" name="pass" value="<?php if (isset($pass) && ($pass != ""))
                echo $pass; ?>">
        </div>
        <div class="row mb10">
             email<br>
            <input type="text" name="email" value="<?php if (isset($email) && ($email != ""))
                echo $email; ?>">
        </div>
        <div class="row mb10">
            địa chỉ <br>
            <input type="text" name="address" value="<?php if (isset($address) && ($address != ""))
                echo $address; ?>">
        </div>
        <div class="row mb10">
            điện thoại<br>
            <input type="text" name="tel" value="<?php if (isset($tel) && ($tel != ""))
                echo $tel; ?>">
        </div>
        <div class="row mb10">
          vai trò<br>
            <input type="text" name="role" value="<?php if (isset($role) && ($role != ""))
                echo $role; ?>">
        </div>
        <div class="row mb10">
            <input type="hidden" name="id" value="<?php if (isset($id) && ($id > 0))
                echo $id; ?>">
            <input type="submit" name="capnhat" value="Cập nhật">
            <a href="index.php?act=dskh"><input type="button" value="Danh sách"></a>
        </div>
        <?php
        if (isset($thongbao) && ($thongbao != "")) {
            echo $thongbao;
        }
        ?>
    </form>
</div>
</div>
</div>