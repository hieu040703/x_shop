<div class="row">
    <h1>Danh sách loại hàng</h1>
</div>
<div class="row frmcontent">
    <form action="#" method="post">
        <div class="row mb10 frmdsloai">
            <table>
                <tr>
                    <th></th>
                    <th>Mã loại</th>
                    <th>Tên loại</th>
                    <th></th>
                </tr>
                <?php
                // print_r($listdanhmuc);
                // die;
                foreach ($listdanhmuc as  $key => $danhmuc) {
                    extract($danhmuc);
                    $suadm = "index.php?act=suadm&id=" . $id;
                    $xoadm = "index.php?act=xoadm&id=" . $id;
                    echo '<tr>
                           <td><input type="checkbox"></td>
                           <td>' . $id . '</td>
                           <td>' . $name . '</td>
                           <td><a href="' . $xoadm . '"> <input type="button" value="xóa"></a> <a href="' . $suadm . '"><input type="button" value="sửa"></a></td>
                       </tr>';
                }
                ?>
            </table>
        </div>
        <div class="row mb10">
            <input type="button" value="Chọn tất cả">
            <input type="button" value="Bỏ chọn tất cả">
            <input type="button" value="Xóa các mục đã chọn">
            <a href="index.php?act=adddm"><input type="button" value="Nhập thêm"></a>
        </div>
    </form>
    </form>
</div>