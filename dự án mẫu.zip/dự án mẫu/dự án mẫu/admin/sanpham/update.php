<?php
if (is_array($sanpham)) {
    extract($sanpham);
   
    
}
if (is_array($listdanhmuc)) {
    extract($listdanhmuc);
  
}

$hinh = "../upload/" . $img;
if (is_file($hinh)) {
    $hinh = "<img src='" . $hinh . "' height='80'>";
} else {
    $hinh = "nophotoshop";
}
?>
<div class="row frmtile">
    <h1>Thêm mới loại hàng hóa</h1>
</div>
<div class="row frmcontent">
<?php
// PHP
//  < 1 năm: 10tr
// 2 đến 3 năm 12=>15tr
// 3 đến 5 năm 25tr => 30tr
// trên 5 năm => 35tr (tuỳ công ty)

// Thu nhập ngoài (freelancee) không cố định
// JAVA (công ty hệ thống lớn)
// 40tr => 45tr (cổ phần đầu tư)
# Thương mại điện tử, API: (php) (ruby, laravel, codeingter, yi) custom(fame) (b1) => 35tr
// FE => fail

# Tiền tệ : ngân hàng, coin, chứng khoán (java) ngoài 35tr ngân hàng (2 => 3 ngàn đô)

# Mô hình MVC BE: model, view, controller
# Code app: (IOS,android) Node JS (BE) tối đa 35tr nhưng là xu hướng tương lai
# Code FE (lương thấp): HTML, CSS, JS, JQUERY (20tr)
# Code (FE lương cao) fame: ReactJS, VeuJS, Angular (30tr)
    // echo '<pre>';
    // var_dump($sanpham);
    // echo '</pre>';
    // die;
    # ID danh mục của sản phẩm $v_category
    # List danh mục của database $listdanhmuc
    # So sánh $v_category == 1 trong các danh mục của list và hiển thị
    // echo $listdanhmuc;
    // echo '<pre>';
    // var_dump($listdanhmuc);
    // echo '</pre>';
    // die;
?>
    <form action="index.php?act=updatesp" method="post" enctype="multipart/form-data">
        <div class="row mb10">
        <select name="id_dm">
            <option value="0" selected>Tát cả</option>
             <?php 
             
             foreach ($listdanhmuc as $key => $value) {
                # Code cu
                // if ($iddm == $value['id']) {
                //     echo '<option value='.$value['id'].' selected >'.$value['name'].'</option>';
                // }
                // echo '<option value='.$value['id'].' >'.$value['name'].'</option>';
                # Code new 1 (toi uu code)
                // $selected = ($sanpham['id_dm'] == $value['id']) ? 'selected' : '';
                // echo '<option value='.$value['id'].' '.$selected.' >'.$value['name'].'</option>';
                # Code new 2 (code dung logic cho nguoi moi)
               
                if ($sanpham['id_dm']==$value['id']) {
                    echo '<option value='.$value['id'].' selected >'.$value['name'].'</option>';
                } else {
                    echo '<option value='.$value['id'].'>'.$value['name'].'</option>';
                } 
             }
             ?>
            </select>
        </div>
        <div class="row mb10">
         <input type="hidden" name="id"  value="<?= $id ?>">
            Tên sản phẩm <br>
            <input type="text" name="tensp" value="<?= $name ?>">
        </div>
        <div class="row mb10">
            giá<br>
            <input type="text" name="giasp" value="<?= $price ?>">
        </div>
        <div class="row mb10">
            hình<br>
            <input type="file" name="hinh">
            <?=$hinh?>
        </div>
        <div class="row mb10">
            mô tả<br>
            <textarea name="mota" id="" cols="30" rows="10"><?= $describe ?></textarea>
        </div>
        <div class="row mb10">
            <input type="submit" name="capnhat" value="Cập nhật">
            <input type="reset" value="Nhập lại">
            <a href="index.php?act=listsp"><input type="button" value="danh sách"></a>
        </div>
        <?php
        if (isset($thongbao) && ($thongbao != "")) {
            echo $thongbao;
        }
        ?>
    </form>
</div>
</div>
</div>