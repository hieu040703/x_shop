<?php
function inser_binhluan($noidung,$iduser,$idpro,$ngaybinhluan)
{
    $sql = "INSERT INTO `binh_luan`(`noidung`, `iduser`, `idpro`, `ngaybinhluan`) 
    VALUES ('{$noidung}','{$iduser}','{$idpro}','{$ngaybinhluan}')";
    pdo_execute($sql);
}
function loadall_binhluan($idpro)   
{
    $sql = "SELECT * FROM `binh_luan` where `idpro`='".$idpro."' order by id desc";
    $listbinhluan=  pdo_query($sql);
    return $listbinhluan;
}
function delete_binhluan($id)
{
    $sql = "DELETE FROM binh_luan WHERE `binh_luan`.`id` = $id";
    // echo $sql;
    // die;
    pdo_execute($sql);
}
?>