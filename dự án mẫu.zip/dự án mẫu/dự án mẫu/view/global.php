<?php
global $_SESSION;
$img_path="../upload/";
?>