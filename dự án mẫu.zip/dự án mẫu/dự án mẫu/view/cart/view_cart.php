<style>
    table tr th {
        padding: 10px;
    }
</style>
<div class="row">
    <div class="boxtile">giỏ hàng</div>
    <div class="row boxconter">
        <div class="boxtile" style="text-align: center;">
            <table>
                <tr>
                    <th>hình</th>
                    <th>sản phẩm</th>
                    <th>đơn giá</th>
                    <th>số lượng</th>
                    <th>thành tiền</th>
                    <th>thao tác</th>
                </tr>
                <?php
                $i = 0;
                $tong = 0;
                foreach ($_SESSION['mycart'] as $cart) {
                    $hinh = $img_path . $cart[2];
                    $thanhtien = $cart[3] * $cart[4];
                    $tong += $thanhtien;
                    $xoasp = '<a href="index.php?act=delcart&id_cart=' . $i . '"><input type="button" value="xóa"></a>';
                    echo '<tr>
                        <td><img src="' . $hinh . '" alt="" height="80px"></td>
                        <td>' . $cart[1] . '</td>
                        <td>' . $cart[3] . '</td>
                        <td>' . $cart[4] . '</td>
                        <td>' . $thanhtien . '</td>
                        <td>' . $xoasp . '</td>
                </tr>';
                    $i += 1;
                }
                echo '<tr>
                       <td colspan="4">tổng đơn hàng</td>
                       <td>' . $tong . '</td>
                       <td></td>
                 </tr>';
                ?>

            </table>
        </div>
    </div>
    <div class="row mb bill">
            <a href="index.php?act=bill"><input type="button" value="Đồng ý Đặt Hàng"></a>
            <a href="index.php?act=delcart"><input type="button" value="Xóa giỏ hàng"></a>
    </div>
</div>